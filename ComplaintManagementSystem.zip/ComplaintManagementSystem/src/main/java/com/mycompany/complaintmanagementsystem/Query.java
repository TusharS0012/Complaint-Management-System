/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.complaintmanagementsystem;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
        /**
 *
 * @author tushar sharma
 */
public class Query {
    
    public static Admin currentAdmin;  // Static variable for admin details
    public static User currentUser;    // Static variable for user details
    private static final String URL = "jdbc:mysql://localhost:3306/student";
    private static final String USER = "root";
    private static final String PASSWORD = "Tushar@123";
    private static Connection connection;
    
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
}
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                System.err.println("Failed to close database connection: " + e.getMessage());
            }
        }
    }
    public static Admin AdminLogin(String adminname, String password) throws SQLException {
        String query = "SELECT * FROM admin WHERE email = ? AND password = ?";
        Connection connection = getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);
             
        preparedStatement.setString(1, adminname);
        preparedStatement.setString(2, password);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        if (resultSet.next()) {
        // If record found, store admin details in static variable
        int id = resultSet.getInt("id");
        String email = resultSet.getString("email");
        String name = resultSet.getString("name");

        // Create Admin object and store in GlobalVariables
        Query.currentAdmin = new Admin(id, email, name);

        System.out.println("Admin logged in: " + Query.currentAdmin.getName());
    } else {
        System.out.println("Invalid admin credentials.");
    }
        closeConnection();   
        return currentAdmin; // Return true if a record is found
        
        }
    public static User UserLogin(String username, String password) throws SQLException {
        String query = "SELECT * FROM student WHERE Email = ? AND Password = ?";
        Connection connection = getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);
             
        preparedStatement.setString(1, username);
        preparedStatement.setString(2, password);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        if (resultSet.next()) {
        // If record found, store user details in static variable
        String email = resultSet.getString("Email");
        String name = resultSet.getString("name");
        String Branch = resultSet.getString("Branch");

        // Create User object and store in GlobalVariables
        Query.currentUser = new User(email, name,Branch);

        System.out.println("User logged in: " + Query.currentUser.getName());
    } else {
        System.out.println("Invalid user credentials.");
    }
        closeConnection();    
        return currentUser; // Return true if a record is found

        }
    public static void loadTableData(DefaultTableModel model, String query) {
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Clear existing data and set column names
            model.setRowCount(0);
            model.setColumnCount(0);
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            // Populate rows
            while (rs.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    rowData[i - 1] = rs.getObject(i);
                }
                model.addRow(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading table data: " + e.getMessage());
        }
    }
     public static int loadNumberofComplaints(){
         try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ) {
        String query = "SELECT COUNT(*) AS total_complaints FROM complaints"; 
        ResultSet rs = stmt.executeQuery(query);
        if (rs.next()) {
        int totalComplaints = rs.getInt("total_complaints");
        return totalComplaints;       
     }
     }  catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
     }
     
     public static int loadPendingComplaints(){
         try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ) {
        String query = "SELECT COUNT(*) AS pending_complaints FROM complaints where status='SUBMITTED'"; 
        ResultSet rs = stmt.executeQuery(query);
        if (rs.next()) {
        int pendingComplaints = rs.getInt("pending_complaints");
        System.out.println("(inside query class)Total Complaints: " + pendingComplaints);
        return pendingComplaints;       
     }
     }  catch (SQLException ex) {
            Logger.getLogger(Query.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
     }
     
     static void loadComplaints(DefaultTableModel model) throws SQLException {
        String query = "SELECT id,user,subject,complaint_date,status FROM complaints"; 
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query);) {
            
            
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Clear existing data and set column names
            model.setRowCount(0);
            model.setColumnCount(0);
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            // Populate rows
            while (rs.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    rowData[i - 1] = rs.getObject(i);
                }
                model.addRow(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading table data: " + e.getMessage());
        }
     }
    
     public static boolean addComplaint(String category, String subject, String description, Date sqlDate, String image) throws SQLException {
            int maxComplaintsPerDay = 1;  // Define the daily limit
            if (canSubmitComplaint(currentUser.getEmail(), maxComplaintsPerDay)) {
        String sql = "INSERT INTO complaints (user, type, subject, description, complaint_date, image) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection connection = getConnection();
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
             
            pstmt.setString(1, currentUser.getEmail());
            pstmt.setString(2, category);
            pstmt.setString(3, subject);
            pstmt.setString(4, description);
            pstmt.setDate(5, sqlDate);
            pstmt.setString(6, image);
            
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;  // Return true if the query was successful
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    } else {
        return false;  // If the user has exceeded the daily limit, return false
    }
}

    public static void AddNewuser(String name, String email, String gender, String password, String branch) throws SQLException {
        try(Connection connection= getConnection();){
            String sql = "INSERT INTO student (name, email, gender, password, branch) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            // Create a PreparedStatemen
            // Set the parameters
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, gender);
            stmt.setString(4, password);
            stmt.setString(5, branch);

            // Execute the query
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new user was added successfully!");
            }
        } catch (SQLException e) {
            throw e;
        }
    }

    public static void AddNewadmin(String name, String email, String gender, String password) throws SQLException {
        try(Connection connection= getConnection();){
            String sql = "INSERT INTO admin (name, email, gender, password, branch) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(sql);
            // Create a PreparedStatement
            // Set the parameters
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, gender);
            stmt.setString(4, password);
            
            // Execute the query
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new admin was added successfully!");
            }
        } catch (SQLException e) {
            throw e;
        }
    }

    public static void RemoveNewuser(String email) throws SQLException{
        try(Connection connection= getConnection()){
           String sql = "DELETE FROM student WHERE email = ?";
           PreparedStatement stmt = connection.prepareStatement(sql);
            // Create a PreparedStatement
            // Set the parameters
            stmt.setString(1, email);
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A user was removed successfully!");
            }
        } catch (Exception e) {
            throw e;
        }
        
    }

    public static void RemoveNewAdmin(String email) throws SQLException{
        try(Connection connection= getConnection()){
           String sql = "DELETE FROM admin WHERE email = ?";
            PreparedStatement stmt = connection.prepareStatement(sql);
            // Create a PreparedStatement
            // Set the parameters
            stmt.setString(1, email);
            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("An admin was removed successfully!");
            }
        } catch (Exception e) {
            throw e;
        }
    }

    public static void submitFeedback(String userid,String feedback) throws SQLException {
        try (Connection connection = getConnection();
             Statement stmt = connection.createStatement();){
            String sql= "INSERT INTO feedback (userid, feedbacktext) VALUES (?, ?)";
            stmt.executeQuery(sql);
        }
        
    }

    public static ResultSet getStatus(String complaintid, String user) throws SQLException {
            Connection connection=getConnection();
            String sql ="SELECT status FROM complaints WHERE id=? AND user=?";
            PreparedStatement stmt =connection.prepareStatement(sql);
            stmt.setString(1,complaintid);
            stmt.setString(2,user);
            
            ResultSet rs = stmt.executeQuery();
            closeConnection();
            return rs;
    }

    static void loadUserComplaints(DefaultTableModel model,String email) {
        String sql="SELECT id,user,subject,complaint_date,status FROM complaints WHERE user =?";
        try (Connection connection = getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);) {
            
            stmt.setString(1,email);
            ResultSet rs=stmt.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Clear existing data and set column names
            model.setRowCount(0);
            model.setColumnCount(0);
            for (int i = 1; i <= columnCount; i++) {
                model.addColumn(metaData.getColumnName(i));
            }

            // Populate rows
            while (rs.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 1; i <= columnCount; i++) {
                    rowData[i - 1] = rs.getObject(i);
                }
                model.addRow(rowData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Error loading table data: " + e.getMessage());
        }
        
    }
    
     static void reviewComplaint(int complaintId) throws SQLException {
        String sql="UPDATE complaints SET status = ? WHERE status = ? AND id=?";
        String id=complaintId+ "";
        try (Connection connection=getConnection();
             PreparedStatement stmt=connection.prepareStatement(sql);){
            
            stmt.setString(1,"Reviewed");
            stmt.setString(2,"Submitted");
            stmt.setString(3,id);

            stmt.executeUpdate();
        }
    }    

    static String forgetPassword(String name, String email) throws SQLException {
    String sql = "SELECT password AS Password FROM student WHERE name = ? AND email = ?";
    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(sql)) {

        stmt.setString(1, name);
        stmt.setString(2, email);

        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                // Extract and return the password
                return rs.getString("Password");
            } else {
                // Log if no rows match
                System.err.println("No matching record found for name: " + name + " and email: " + email);
            }
        }
    }
    return null; // Return null if no matching record is found
    }
    public static boolean canSubmitComplaint(String email, int maxComplaintsPerDay) throws SQLException {
    String sql = "SELECT COUNT(*) FROM complaints WHERE user = ? AND DATE(complaint_date) = CURRENT_DATE";
    
    try (Connection connection = getConnection();
         PreparedStatement stmt = connection.prepareStatement(sql)) {
        
        stmt.setString(1, email);
        
        try (ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                int complaintCount = rs.getInt(1);  // Number of complaints submitted today
                return complaintCount < maxComplaintsPerDay;  // Check if under limit
            }
        }
    }
    return false; // In case of any error, return false (e.g., no complaints made today)
}
    static void UpdateDetails(String name, String email, String branch,String currentemail) throws SQLException{
        String sql="UPDATE student SET name = ?, email = ?, branch = ? WHERE email = ?";
        try(Connection connection = getConnection();
     PreparedStatement stmt = connection.prepareStatement(sql)) {

    stmt.setString(1, name); 
    stmt.setString(2, email); 
    stmt.setString(3, branch); 
    stmt.setString(4, currentemail);                     

    stmt.executeUpdate();
    }
    }
     
    protected static class Admin {
    protected int id;
    protected String email;
    protected String name;

    // Constructor
    public Admin(int id, String email, String name) {
        this.id = id;
        this.email = email;
        this.name = name;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    }

    protected static class User {
    protected String branch;
    protected String email;
    protected String name;

    // Constructor
    public User(String email, String name,String Branch) {
        this.email = email;
        this.name = name;
        this.branch= Branch;
    }

    // Getters and Setters

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }
     public String getBranch() {
        return branch;
    }
    }
    
}
    
